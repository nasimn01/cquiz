


<div class="container-fluid pt-4 px-4">
    <div class="row vh-100 bg-secondary rounded align-items-center justify-content-center mx-0">
        <div class="col-md-6 text-center">
            <h1 class="text-info">Congratulations!</h1>
            <p>You have successfully submitted your answers</p>
            <p>Thank You</p>
        </div>
    </div>
</div>