

        <?php $this->load->view('include/header') ?>
        <!-- Sidebar Start -->
        <?php $this->load->view('include/sidebar') ?>

        <?php $this->load->view('include/topbar') ?>
        <!-- Sidebar End -->
        <?php $this->load->view($page) ?>

        <?php $this->load->view('include/footer') ?>