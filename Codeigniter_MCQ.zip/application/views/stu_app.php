

        <?php $this->load->view('include/stu_header') ?>
        <!-- Sidebar Start -->
        <?php $this->load->view('include/stu_sidebar') ?>

        <?php $this->load->view('include/stu_topbar') ?>
        <!-- Sidebar End -->
        <?php $this->load->view($pages) ?>

        <?php $this->load->view('include/stu_footer') ?>